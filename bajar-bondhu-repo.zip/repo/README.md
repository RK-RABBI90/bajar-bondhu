# বাজার বন্ধু (Bajar Bondhu)

ক্রেতা ও বিক্রেতার বিশ্বস্ত মার্কেটপ্লেস। বাংলা-প্রথম PWA।

## বর্তমান অবস্থা

| অংশ | অবস্থা |
|---|---|
| `app/` ফ্রন্টএন্ড প্রোটোটাইপ (vanilla JS, `localStorage`) | চালু, ব্যাকএন্ড ছাড়া |
| `supabase/migrations/0001_init.sql` ডেটাবেস স্কিমা + RLS + `place_order()` | লেখা হয়েছে, এখনো পরীক্ষিত নয় |
| OTP লগইন, API সংযোগ, পেমেন্ট, বিক্রেতা যাচাই | পরিকল্পিত |

## ফ্রন্টএন্ড চালানো

```bash
cd app
python3 -m http.server 8080
# http://localhost:8080
```

Service worker শুধু `localhost` বা HTTPS-এ কাজ করে।

## ডেটাবেস সেটআপ

1. [supabase.com](https://supabase.com)-এ নতুন প্রজেক্ট খুলুন।
2. SQL Editor-এ `supabase/migrations/0001_init.sql` পুরোটা চালান।
3. Storage-এ দুটি bucket বানান: `product-images` (public read), `seller-docs` (private)।

## রোডম্যাপ

- [x] A1: কোর বাগ ফিক্স
- [x] B1: ডেটাবেস স্কিমা
- [x] ক্রেতার ডেলিভারি ঠিকানা + ক্যাশ অন ডেলিভারি (ফ্রন্টএন্ড)
- [ ] A2: ফন্ট সেলফ-হোস্ট
- [ ] B2: ফোন OTP লগইন
- [ ] B3: পণ্য, ছবি ও অর্ডার API সংযোগ
- [ ] B4: bKash/Nagad পেমেন্ট ও বিক্রেতা যাচাই
