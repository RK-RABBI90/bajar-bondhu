-- =====================================================================
-- বাজার বন্ধু — Supabase/Postgres schema (ধাপ B1)
-- নিয়ম: দাম সবসময় পয়সায় (bigint)। ক্লায়েন্টের পাঠানো দাম কখনো বিশ্বাস করা হয় না;
-- অর্ডার শুধু place_order() ফাংশন দিয়ে হয়, যেখানে দাম ও স্টক DB থেকে নেওয়া হয়।
-- Supabase SQL Editor-এ পুরোটা একবারে চালান।
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------- enums ----------
create type seller_status   as enum ('pending', 'verified', 'rejected', 'suspended');
create type product_status  as enum ('active', 'hidden');
create type payment_method  as enum ('cod', 'bkash', 'nagad', 'card');
create type payment_status  as enum ('unpaid', 'paid', 'refunded');
create type fulfil_status   as enum ('pending', 'confirmed', 'shipped', 'delivered', 'cancelled');

-- ---------- profiles (auth.users-এর সাথে ১:১) ----------
create table profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  full_name  text check (char_length(full_name) <= 80),
  phone      text,                      -- +8801XXXXXXXXX
  created_at timestamptz not null default now()
);

create function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, phone) values (new.id, new.phone);
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- ---------- sellers ----------
create table sellers (
  id            uuid primary key default gen_random_uuid(),
  owner_id      uuid not null unique references profiles(id) on delete cascade,
  shop_name     text not null check (char_length(shop_name) between 2 and 60),
  shop_address  text,
  nid_doc_path  text,                   -- Storage-এর private bucket 'seller-docs'
  status        seller_status not null default 'pending',
  created_at    timestamptz not null default now()
);
create unique index sellers_shop_name_uq on sellers (lower(shop_name));  -- নকল দোকান আটকাতে

-- ---------- categories ----------
create table categories (
  id      smallint generated always as identity primary key,
  slug    text not null unique,
  name_bn text not null
);

insert into categories (slug, name_bn) values
  ('electronics', 'ইলেকট্রনিক্স'),
  ('fashion',     'ফ্যাশন'),
  ('grocery',     'মুদি ও খাদ্য'),
  ('home',        'গৃহসামগ্রী'),
  ('books',       'বই ও স্টেশনারি'),
  ('beauty',      'স্বাস্থ্য ও সৌন্দর্য'),
  ('toys',        'খেলনা'),
  ('vehicles',    'যানবাহন');

-- ---------- products ----------
create table products (
  id           uuid primary key default gen_random_uuid(),
  seller_id    uuid not null references sellers(id) on delete cascade,
  category_id  smallint not null references categories(id),
  title        text not null check (char_length(title) between 2 and 120),
  description  text check (char_length(description) <= 2000),
  price_paisa  bigint not null check (price_paisa > 0),   -- ৳১২৫০ = 125000
  stock        integer not null default 0 check (stock >= 0),
  image_paths  text[] not null default '{}',               -- Storage bucket 'product-images'
  status       product_status not null default 'active',
  created_at   timestamptz not null default now()
);
create index products_cat_idx    on products (category_id) where status = 'active';
create index products_seller_idx on products (seller_id);
-- বাংলা সার্চের জন্য সাধারণ trigram (ধাপ পরে উন্নত করা হবে)
create extension if not exists pg_trgm;
create index products_title_trgm on products using gin (title gin_trgm_ops);

-- ---------- addresses ----------
create table addresses (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references profiles(id) on delete cascade,
  recipient  text not null,
  phone      text not null check (phone ~ '^(\+8801|01)[3-9][0-9]{8}$'),
  division   text not null,
  district   text not null,
  upazila    text not null,
  line       text not null,            -- বাড়ি/রাস্তা/এলাকা
  created_at timestamptz not null default now()
);

-- ---------- orders ----------
create table orders (
  id               uuid primary key default gen_random_uuid(),
  buyer_id         uuid not null references profiles(id),
  address_snapshot jsonb not null,     -- ঠিকানা পরে বদলালেও পুরনো অর্ডার অপরিবর্তিত
  payment_method   payment_method not null,
  payment_status   payment_status not null default 'unpaid',
  total_paisa      bigint not null default 0 check (total_paisa >= 0),
  created_at       timestamptz not null default now()
);
create index orders_buyer_idx on orders (buyer_id, created_at desc);

-- একাধিক বিক্রেতার পণ্য এক অর্ডারে থাকতে পারে, তাই ফুলফিলমেন্ট স্ট্যাটাস আইটেম-লেভেলে
create table order_items (
  id               uuid primary key default gen_random_uuid(),
  order_id         uuid not null references orders(id) on delete cascade,
  product_id       uuid not null references products(id),
  seller_id        uuid not null references sellers(id),
  title_snapshot   text not null,
  unit_price_paisa bigint not null check (unit_price_paisa > 0),
  qty              integer not null check (qty between 1 and 50),
  status           fulfil_status not null default 'pending'
);
create index order_items_order_idx  on order_items (order_id);
create index order_items_seller_idx on order_items (seller_id, status);

-- ---------- helper (RLS recursion এড়াতে) ----------
create function is_seller_owner(p_seller uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from sellers where id = p_seller and owner_id = auth.uid());
$$;

create function is_verified_seller_owner(p_seller uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from sellers
                 where id = p_seller and owner_id = auth.uid() and status = 'verified');
$$;

-- ---------- Row Level Security ----------
alter table profiles    enable row level security;
alter table sellers     enable row level security;
alter table categories  enable row level security;
alter table products    enable row level security;
alter table addresses   enable row level security;
alter table orders      enable row level security;
alter table order_items enable row level security;

create policy profiles_own_select on profiles for select using (id = auth.uid());
create policy profiles_own_update on profiles for update using (id = auth.uid()) with check (id = auth.uid());

create policy categories_read on categories for select using (true);

create policy sellers_read on sellers for select
  using (status = 'verified' or owner_id = auth.uid());
create policy sellers_apply on sellers for insert
  with check (owner_id = auth.uid() and status = 'pending');
create policy sellers_update_own on sellers for update
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());
-- নিজের status বদলানো যাবে না (শুধু অ্যাডমিন/service role পারবে)
revoke update on sellers from authenticated;
grant  update (shop_name, shop_address, nid_doc_path) on sellers to authenticated;

create policy products_read on products for select
  using (
    (status = 'active' and exists (select 1 from sellers s where s.id = seller_id and s.status = 'verified'))
    or is_seller_owner(seller_id)
  );
create policy products_insert on products for insert with check (is_verified_seller_owner(seller_id));
create policy products_update on products for update
  using (is_seller_owner(seller_id)) with check (is_verified_seller_owner(seller_id));
create policy products_delete on products for delete using (is_seller_owner(seller_id));

create policy addresses_own on addresses for all
  using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy orders_buyer_read on orders for select using (buyer_id = auth.uid());
-- orders-এ insert/update নীতি নেই: শুধু place_order() (security definer) লিখতে পারে

create policy items_read on order_items for select
  using (
    exists (select 1 from orders o where o.id = order_id and o.buyer_id = auth.uid())
    or is_seller_owner(seller_id)
  );
create policy items_seller_update on order_items for update
  using (is_seller_owner(seller_id)) with check (is_seller_owner(seller_id));
revoke update on order_items from authenticated;
grant  update (status) on order_items to authenticated;

-- ---------- অর্ডার দেওয়ার একমাত্র পথ ----------
-- p_items উদাহরণ: [{"product_id":"<uuid>","qty":2}]
create function place_order(p_address_id uuid, p_payment payment_method, p_items jsonb)
returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_order uuid;
  v_total bigint := 0;
  v_addr  addresses;
  v_prod  products;
  r       record;
begin
  if auth.uid() is null then raise exception 'লগইন করুন'; end if;
  if p_payment = 'card' then raise exception 'এই পেমেন্ট পদ্ধতি এখনো চালু হয়নি'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) not between 1 and 50 then
    raise exception 'কার্ট খালি বা অবৈধ';
  end if;

  select * into v_addr from addresses where id = p_address_id and user_id = auth.uid();
  if not found then raise exception 'ঠিকানা পাওয়া যায়নি'; end if;

  insert into orders (buyer_id, address_snapshot, payment_method)
  values (auth.uid(), to_jsonb(v_addr), p_payment)
  returning id into v_order;

  for r in
    select (e->>'product_id')::uuid as pid, (e->>'qty')::int as qty
    from jsonb_array_elements(p_items) e
  loop
    if r.qty is null or r.qty < 1 or r.qty > 50 then raise exception 'পরিমাণ অবৈধ'; end if;

    -- স্টক কমানো ও চেক একই স্টেটমেন্টে (race condition নেই)
    update products p set stock = p.stock - r.qty
    where p.id = r.pid and p.status = 'active' and p.stock >= r.qty
      and exists (select 1 from sellers s where s.id = p.seller_id and s.status = 'verified')
    returning p.* into v_prod;

    if not found then raise exception 'পণ্যটি স্টকে নেই বা বিক্রির জন্য উপলব্ধ নয়'; end if;
    if is_seller_owner(v_prod.seller_id) then raise exception 'নিজের পণ্য কেনা যাবে না'; end if;

    insert into order_items (order_id, product_id, seller_id, title_snapshot, unit_price_paisa, qty)
    values (v_order, v_prod.id, v_prod.seller_id, v_prod.title, v_prod.price_paisa, r.qty);

    v_total := v_total + v_prod.price_paisa * r.qty;
  end loop;

  update orders set total_paisa = v_total where id = v_order;
  return v_order;
end $$;

revoke all on function place_order(uuid, payment_method, jsonb) from public;
grant execute on function place_order(uuid, payment_method, jsonb) to authenticated;

-- =====================================================================
-- Storage (Dashboard থেকে বানান):
--   product-images : public read, লেখা শুধু verified seller (পথ: <seller_id>/<file>)
--   seller-docs    : PRIVATE; শুধু মালিক ও অ্যাডমিন পড়তে পারবে
-- =====================================================================
